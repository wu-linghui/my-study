// @ts-check
/* eslint-disable */

//* ****** EcmaScript 2015 (ES6): Template literals (https://goo.gl/4N36CS)
const book = {
  name: 'Learning JavaScript DataStructures and Algorithms'
};

console.log('You are reading ' + book.name + '.,\n	and this is a new line\n	and so is this.');

console.log(`You are reading ${book.name}.,
   and this is a new line
    and so is this.`);

