const { minCoinChange } = PacktDataStructuresAlgorithms;

console.log(minCoinChange([1, 5, 10], 15)); // [5, 10]
console.log(minCoinChange([1, 3, 4], 6)); // [3, 3]

