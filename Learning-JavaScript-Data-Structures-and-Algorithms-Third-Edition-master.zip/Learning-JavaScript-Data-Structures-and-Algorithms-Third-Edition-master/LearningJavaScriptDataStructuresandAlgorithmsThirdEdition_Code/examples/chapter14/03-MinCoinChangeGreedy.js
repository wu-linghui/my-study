const { minCoinChangeGreedy } = PacktDataStructuresAlgorithms;

console.log(minCoinChangeGreedy([1, 5, 10], 15)); // [5, 10]
console.log(minCoinChangeGreedy([1, 3, 4], 6)); // [4, 1, 1]

